/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author nc
 */
class Item {
    private int id;
    private String category;
    private String name;
    private int price;
    private int qty;

    public Item(int id, String category, String name, int price, int qty) {
        this.id = id;
        this.category = category;
        this.name = name;
        this.price = price;
        this.qty = qty;
    }

    public Item() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPirce(int price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    @Override
    public String toString() {
        
        return category + " (" + name + ") - "+ price + " * " + qty +"=" + price * qty;
    }
    
    public int increaseQty(){
        
        return qty++;

    }
    
    public int getTotal(){
        
        return price * qty;
    }
}
