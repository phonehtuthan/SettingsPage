/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package javaapplication1;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Category extends javax.swing.JFrame {

    public DefaultTableModel model=new DefaultTableModel();
    public String cols[]={"id","name"};
    
    public JPopupMenu mainMenu=new JPopupMenu();
    public JMenuItem editMenu=new JMenuItem("Edit Category");
    public JMenuItem deleteMenu=new JMenuItem("Delete Category");

    public Category() {
        
        initComponents();
        
        loadCategory();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Create Category");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(88, 88, 88))
            .addGroup(layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 45, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        this.dispose();
        
        CreateCategory createCategoryPage=new CreateCategory();
        
        createCategoryPage.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Category.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Category.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Category.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Category.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            
            public void run() {
                new Category().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    private void loadCategory() {
         
        model.setColumnIdentifiers(cols);
        
        try
            
        {
            Database db=new Database();
            Connection conn=db.getConnected();
            
            String sql="SELECT * from Category ";
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            
            while(rs.next()){
                
                int id=rs.getInt("id");
                String name=rs.getString("name");
                
                model.addRow(new Object[]{id,name});
                
            }
            
            jTable1.setModel(model);
            jTable1.setComponentPopupMenu(mainMenu);
            mainMenu.add(editMenu);
            mainMenu.add(deleteMenu);
            
            editMenu.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    
                    int row=jTable1.getSelectedRow();
                    int col=0;
                    int id=(int) jTable1.getValueAt(row, col);
                            
                    String category_name="";        
                    
                    try{
                        
                        Database db=new Database();
                        Connection conn=db.getConnected();
                        
                        String sql="SELECT * from Category where id="+id;
                        Statement stmt=conn.createStatement();
                        ResultSet rs=stmt.executeQuery(sql);
                        while(rs.next()){
                            
                            category_name=rs.getString("name");
                        }
                    }
                    
                    catch(Exception e4){
                        
                        e4.printStackTrace();
                    }
                    
                    JFrame editWindow=new JFrame("Edit Category");
                    editWindow.setLayout(null);
                    
                    JLabel title=new JLabel("Edit Category");
                    title.setBounds(50,50,300,30);
                    title.setFont(new Font("times",Font.BOLD,20));
                    editWindow.add(title);
                    
                    JButton closeBtn=new JButton("[*] Close ");
                    closeBtn.setBounds(350,50,100,30);
                    editWindow.add(closeBtn);
                    closeBtn.setBackground(Color.gray);
                    
                    closeBtn.addActionListener(new ActionListener(){
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            editWindow.setVisible(false);
                        }
                    });
                    
                    JLabel name_lb=new JLabel("Name");
                    name_lb.setBounds(50,150,200,30);
                    editWindow.add(name_lb);
                    
                    JTextField name_tf=new JTextField(category_name);
                    name_tf.setBounds(350,150,200,30);
                    editWindow.add(name_tf);
                    
                    JButton updateBtn=new JButton("Update");
                    updateBtn.setBounds(350,200,100,30);
                    editWindow.add(updateBtn);
                    
                    updateBtn.addActionListener(new ActionListener(){
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            
                            try{
                                
                                Database db=new Database();
                                Connection conn=db.getConnected();
                                
                                String sql="UPDATE Category set name=? WHERE id=?";
                                PreparedStatement pst=conn.prepareStatement(sql);
                                pst.setString(1,name_tf.getText());
                                pst.setInt(2,id);
                                pst.execute();
                                
                                JOptionPane.showMessageDialog(null, " Successfully Updated...");
                                dispose();
                                editWindow.dispose();
                                
                                Category categoryPage=new Category();
                                categoryPage.setVisible(true);
                                
                            }
                            
                            catch(Exception e3){
                                
                                e3.printStackTrace();
                            }
                        }
                        
                    });
                    
                    editWindow.setDefaultCloseOperation(EXIT_ON_CLOSE);
                    editWindow.setSize(600,650);
                    editWindow.setLocationRelativeTo(null);
                    editWindow.setVisible(true);
                }
            
            });
            
            deleteMenu.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                   
                   int row=jTable1.getSelectedRow();
                   int col=0;
                   int id=(int)jTable1.getValueAt(row, col);
                    
                   try{
                       
                       Database db=new Database();
                       Connection conn=db.getConnected();
                       
                       String sql="DELETE from Category where id="+id;
                       
                       Statement stmt=conn.createStatement();
                       
                       stmt.execute(sql);
                       
                       JOptionPane.showMessageDialog(null, "Successfully Deleted...");
                       
                       dispose();
                       
                       Category categoryPage=new Category();
                       categoryPage.setVisible(true);    
                    }
                 catch(Exception e5){
                     e5.printStackTrace();
                    }
                }
                
            });
            
        }
        catch(Exception e2){
            
            e2.printStackTrace();
        }
    }
}
